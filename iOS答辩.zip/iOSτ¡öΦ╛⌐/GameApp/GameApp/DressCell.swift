//
//  DressCell.swift
//  GameApp
//
//  Created by 94_F on 2019/12/14.
//  Copyright © 2019 Name. All rights reserved.
//

import UIKit

class DressCell: UITableViewCell {

    @IBOutlet weak var Dress: UIImageView!
    @IBOutlet weak var DressingSign: UIImageView!
    
    var DressSeq: Int?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
