//
//  Structure.swift
//  GameApp
//
//  Created by 94_F on 2019/12/14.
//  Copyright © 2019 Name. All rights reserved.
//

import UIKit
import Foundation

class DressList : NSObject, NSCoding {
    
    var DressName: String?
    var DressGotten: [Bool]?
    var DressingNum: Int?
    
    init(dressName: String?, dressGotten: [Bool]?, dressingNum: Int?){
        self.DressName = dressName
        self.DressGotten = dressGotten
        self.DressingNum = dressingNum
    }
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(DressName, forKey: "dressName")
        aCoder.encode(DressGotten, forKey: "dressGotten")
        aCoder.encode(DressingNum, forKey: "dressingNum")
    }
    
    required init?(coder aDecoder: NSCoder) {
        DressName = aDecoder.decodeObject(forKey: "dressName") as? String
        DressGotten = aDecoder.decodeObject(forKey: "dressGotten") as? [Bool]
        DressingNum = aDecoder.decodeObject(forKey: "dressingNum") as? Int
    }
    
    static let DocumentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    static let HeadArchiveURL = DocumentsDirectory.appendingPathComponent("HeadData")
    static let ClothesArchiveURL = DocumentsDirectory.appendingPathComponent("ClothesData")
    static let PantsArchiveURL = DocumentsDirectory.appendingPathComponent("PantsData")
    
    func DressInit(named: String){
        DressName = named
        DressGotten = [Bool]()
        for _ in 1...5{
            DressGotten!.append(false)
        }
        DressingNum = -1
    }

}

var HeadList: DressList = DressList(dressName: nil, dressGotten: nil, dressingNum: nil)
var ClothesList: DressList = DressList(dressName: nil, dressGotten: nil, dressingNum: nil)
var PantsList: DressList = DressList(dressName: nil, dressGotten: nil, dressingNum: nil)
var HeadImageList: [UIImage] = [UIImage]()
var HeadSmallImageList: [UIImage] = [UIImage]()
var ClothesImageList: [UIImage] = [UIImage]()
var ClothesSmallImageList: [UIImage] = [UIImage]()
var PantsImageList: [UIImage] = [UIImage]()
var PantsSmallImageList: [UIImage] = [UIImage]()
var YesImage: UIImage = UIImage(named: "YES")!
var NoImage: UIImage = UIImage(named: "NO")!

func HeadSave(){
    let success = NSKeyedArchiver.archiveRootObject(HeadList, toFile: DressList.HeadArchiveURL.path)
    if !success {
        print("Failed ...")
    }
}
func ClothesSave(){
    let success = NSKeyedArchiver.archiveRootObject(ClothesList, toFile: DressList.ClothesArchiveURL.path)
    if !success {
        print("Failed ...")
    }
}
func PantsSave(){
    let success = NSKeyedArchiver.archiveRootObject(PantsList, toFile: DressList.PantsArchiveURL.path)
    if !success {
        print("Failed ...")
    }
}
func HeadLoad() -> DressList?{
    return (NSKeyedUnarchiver.unarchiveObject(withFile: DressList.HeadArchiveURL.path) as? DressList)
}
func ClothesLoad() -> DressList?{
    return (NSKeyedUnarchiver.unarchiveObject(withFile: DressList.ClothesArchiveURL.path) as? DressList)
}
func PantsLoad() -> DressList?{
    return (NSKeyedUnarchiver.unarchiveObject(withFile: DressList.PantsArchiveURL.path) as? DressList)
}

class Challenge{
    var Question: String = String()
    var Choose: [String] = [String]()
    var Answer: Int = Int()
}
