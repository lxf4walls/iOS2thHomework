//
//  ViewController.swift
//  GameApp
//
//  Created by 94_F on 2019/12/14.
//  Copyright © 2019 Name. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

