//
//  ChallengeCell.swift
//  GameApp
//
//  Created by 94_F on 2019/12/15.
//  Copyright © 2019 Name. All rights reserved.
//

import UIKit

class ChallengeCell: UITableViewCell {

    @IBOutlet weak var Dress: UIImageView!
    @IBOutlet weak var GottenSign: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
