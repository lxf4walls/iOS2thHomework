//
//  ChallengeVC.swift
//  GameApp
//
//  Created by 94_F on 2019/12/15.
//  Copyright © 2019 Name. All rights reserved.
//

import UIKit

class ChallengeVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var Q: Challenge?
    var QSeq: Int?
    
    @IBOutlet weak var QuestionText: UILabel!
    @IBOutlet weak var AnswerTable: UITableView!
    @IBOutlet weak var YorN: UILabel!
    @IBOutlet weak var CorrectAnswer: UILabel!
    @IBOutlet weak var GetTip: UIStackView!
    @IBOutlet weak var Dress: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        AnswerTable.delegate = self
        AnswerTable.dataSource = self
        QuestionText.text = Q!.Question
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "QuestionCell", for: indexPath)
        cell.textLabel?.text = Q!.Choose[indexPath.row]
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row + 1 == Q!.Answer{
            YorN.text = "回答正确"
            YorN.textColor = UIColor.green
            YorN.isHidden = false
        } else {
            YorN.text = "回答错误"
            YorN.textColor = UIColor.red
            YorN.isHidden = false
            switch (Q!.Answer){
            case 1:
                CorrectAnswer.text = "正确答案是:" + "a"
            case 2:
                CorrectAnswer.text = "正确答案是:" + "b"
            case 3:
                CorrectAnswer.text = "正确答案是:" + "c"
            case 4:
                CorrectAnswer.text = "正确答案是:" + "d"
            default:
                break
            }
            CorrectAnswer.isHidden = false
        }
        switch (QSeq!) {
        case 0:
            fallthrough
        case 1:
            fallthrough
        case 2:
            fallthrough
        case 3:
            fallthrough
        case 4:
            if HeadList.DressGotten![QSeq!%5] == false{
                Dress.image = HeadSmallImageList[QSeq!%5]
                HeadList.DressGotten![QSeq!%5] = true
                GetTip.isHidden = false
                HeadSave()
            }
        case 5:
            fallthrough
        case 6:
            fallthrough
        case 7:
            fallthrough
        case 8:
            fallthrough
        case 9:
            if ClothesList.DressGotten![QSeq!%5] == false{
                Dress.image = ClothesSmallImageList[QSeq!%5]
                ClothesList.DressGotten![QSeq!%5] = true
                GetTip.isHidden = false
                ClothesSave()
            }
        case 10:
            fallthrough
        case 11:
            fallthrough
        case 12:
            fallthrough
        case 13:
            fallthrough
        case 14:
            if PantsList.DressGotten![QSeq!%5] == false{
                Dress.image = PantsSmallImageList[QSeq!%5]
                PantsList.DressGotten![QSeq!%5] = true
                GetTip.isHidden = false
                PantsSave()
            }
        default:
            break
        }
        AnswerTable.isUserInteractionEnabled = false
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
