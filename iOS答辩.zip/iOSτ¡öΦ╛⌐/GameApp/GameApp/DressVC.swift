//
//  DressVC.swift
//  GameApp
//
//  Created by 94_F on 2019/12/14.
//  Copyright © 2019 Name. All rights reserved.
//

import UIKit

class DressVC: UIViewController, UITabBarDelegate, UITableViewDelegate, UITableViewDataSource {
    
    
    
    var TableSeq = 1
    
    @IBOutlet weak var HeadImage: UIImageView!
    @IBOutlet weak var ClothesImage: UIImageView!
    @IBOutlet weak var PantsImage: UIImageView!
    @IBOutlet weak var TabBar: UITabBar!
    @IBOutlet weak var HeadTab: UITabBarItem!
    @IBOutlet weak var ClothesTab: UITabBarItem!
    @IBOutlet weak var PantsTab: UITabBarItem!
    @IBOutlet weak var DressTable: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        TabBar.delegate = self
        TabBar.selectedItem = HeadTab
        HeadTab.tag = 1
        ClothesTab.tag = 2
        PantsTab.tag = 3
        
        DressTable.delegate = self
        DressTable.dataSource = self
        DressTable.rowHeight = 70
        
        if HeadList.DressingNum! > 0{
            HeadImage.image = HeadImageList[HeadList.DressingNum! - 1]
        }
        if ClothesList.DressingNum! > 0{
            ClothesImage.image = ClothesImageList[ClothesList.DressingNum! - 1]
        }
        if PantsList.DressingNum! > 0{
            PantsImage.image = PantsImageList[PantsList.DressingNum! - 1]
        }
    }
    
    func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        switch (item.tag) {
        case 1:
            TableSeq = 1
        case 2:
            TableSeq = 2
        case 3:
            TableSeq = 3
        default:
            break;
        }
        DressTable.reloadData()
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        var CellCount: Int = 0
        switch (TableSeq) {
        case 1:
            for i in 0...4{
                if HeadList.DressGotten![i]{
                    CellCount += 1
                }
            }
        case 2:
            for i in 0...4{
                if ClothesList.DressGotten![i]{
                    CellCount += 1
                }
            }
        case 3:
            for i in 0...4{
                if PantsList.DressGotten![i]{
                    CellCount += 1
                }
            }
        default:
            break
        }
        return CellCount
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DressCell", for: indexPath) as! DressCell
        cell.selectionStyle = UITableViewCell.SelectionStyle.none
        var SeqCheck = 0
        switch (TableSeq) {
        case 1:
            for i in 0...4{
                if HeadList.DressGotten![i]{
                    if SeqCheck == indexPath.row{
                        cell.DressSeq = i+1
                        cell.Dress.image = HeadSmallImageList[i]
                        if cell.DressSeq == HeadList.DressingNum!{
                            cell.DressingSign.image = YesImage
                        } else {
                            cell.DressingSign.image = NoImage
                        }
                        break
                    } else {
                        SeqCheck += 1
                    }
                }
            }
        case 2:
            for i in 0...4{
                if ClothesList.DressGotten![i]{
                    if SeqCheck == indexPath.row{
                        cell.DressSeq = i+1
                        cell.Dress.image = ClothesSmallImageList[i]
                        if cell.DressSeq == ClothesList.DressingNum!{
                            cell.DressingSign.image = YesImage
                        } else {
                            cell.DressingSign.image = NoImage
                        }
                        break
                    } else {
                        SeqCheck += 1
                    }
                }
            }
        case 3:
            for i in 0...4{
                if PantsList.DressGotten![i]{
                    if SeqCheck == indexPath.row{
                        cell.DressSeq = i+1
                        cell.Dress.image = PantsSmallImageList[i]
                        if cell.DressSeq == PantsList.DressingNum!{
                            cell.DressingSign.image = YesImage
                        } else {
                            cell.DressingSign.image = NoImage
                        }
                        break
                    } else {
                        SeqCheck += 1
                    }
                }
            }
        default:
            break
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tableView.cellForRow(at: indexPath) as! DressCell
        switch (TableSeq) {
        case 1:
            if cell.DressSeq! == HeadList.DressingNum!{
                HeadList.DressingNum = -1
                HeadImage.isHidden = true
            } else {
                HeadList.DressingNum = cell.DressSeq!
                HeadImage.image = HeadImageList[HeadList.DressingNum! - 1]
                HeadImage.isHidden = false
            }
            HeadSave()
        case 2:
            if cell.DressSeq! == ClothesList.DressingNum!{
                ClothesList.DressingNum = -1
                ClothesImage.isHidden = true
            } else {
                ClothesList.DressingNum = cell.DressSeq!
                ClothesImage.image = ClothesImageList[ClothesList.DressingNum! - 1]
                ClothesImage.isHidden = false
            }
            ClothesSave()
        case 3:
            if cell.DressSeq! == PantsList.DressingNum!{
                PantsList.DressingNum = -1
                PantsImage.isHidden = true
            } else {
                PantsList.DressingNum = cell.DressSeq!
                PantsImage.image = PantsImageList[PantsList.DressingNum! - 1]
                PantsImage.isHidden = false
            }
            PantsSave()
        default:
            break
        }
        tableView.reloadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(false, animated: true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
