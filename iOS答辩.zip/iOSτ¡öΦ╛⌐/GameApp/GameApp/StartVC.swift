//
//  StartVC.swift
//  GameApp
//
//  Created by 94_F on 2019/12/15.
//  Copyright © 2019 Name. All rights reserved.
//

import UIKit

class StartVC: UIViewController {
    
    @IBOutlet weak var Navigation: UINavigationItem!
    
    func DataInit(){
        if HeadLoad() != nil{
            HeadList = HeadLoad()!
        } else {
            HeadList.DressInit(named: "Head")
        }
        if ClothesLoad() != nil{
            ClothesList = ClothesLoad()!
        } else {
            ClothesList.DressInit(named: "Clothes")
        }
        if PantsLoad() != nil{
            PantsList = PantsLoad()!
        } else {
            PantsList.DressInit(named: "Pants")
        }
        for i in 1...5{
            HeadImageList.append(UIImage(named: HeadList.DressName! + String(i))!)
            HeadSmallImageList.append(UIImage(named: HeadList.DressName! + String(i) + "_small")!)
            ClothesImageList.append(UIImage(named: ClothesList.DressName! + String(i))!)
            ClothesSmallImageList.append(UIImage(named: ClothesList.DressName! + String(i) + "_small")!)
            PantsImageList.append(UIImage(named: PantsList.DressName! + String(i))!)
            PantsSmallImageList.append(UIImage(named: PantsList.DressName! + String(i) + "_small")!)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        DataInit()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
