{
    "type":"ml",
    "bunldID":"alita_waimai-markting-slientrecall-dynamic",
    "version":"0.0.7"
}
